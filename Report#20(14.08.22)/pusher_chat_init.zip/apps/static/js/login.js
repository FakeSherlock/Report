function fblogin() {
    var name;

}

$(document).ready(function () {
    $('#facebook-btn').click(function () {


    });
});