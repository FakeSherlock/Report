# -*- coding: utf-8 -*-
from flask import Flask, request, render_template, jsonify
from apps import app


@app.route('/')
def index():
    return render_template('login.html')

@app.route('/chat/<chat_id>')
def chat(chat_id):

    return render_template('chat.html')

@app.route('/send', methods=['GET'])
def send():

    return ""

@app.route('/login', methods=['GET'])
def login():

    return jsonify(chat_id=880803)

# @app.route('/logout', methods=['GET'])
# def logout():
#
#
#     return ""